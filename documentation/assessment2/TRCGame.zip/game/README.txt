Note please extract all files to the same directory before attempting to run the game
Please do not change any of the directory or file names or their relative locations.
